package controllers;

import play.mvc.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

// Imports model class
import models.*;

// Imports views
import views.html.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    // Declaring a private FormFactory instance
    private FormFactory formFactory;

    // Injecting an instance of FormFactory into the controller via its constructor
    @Inject
    public HomeController(FormFactory f){
        this.formFactory = f;
    }
    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {

        List<Product> productList = Product.findAll();

        return ok(index.render(productList));
    }

    public Result addProduct(){

        // Create a form by wrapping the Product Class
        // in a FormFactory form instance
        Form<Product> productForm = formFactory.form(Product.class);

        return ok(addProduct.render(productForm));
    }

    public Result addProductSumbit(){
        
        // Retrieve the submitted form object( bind from the HTTP request)
        Form<Product> newProductForm = formFactory.form(Product.class).bindFromRequest();

        // Check for erroors (based on constraints set in the Product class)
        if(newProductForm.hasErrors()) {
            // Display the form again by returning a bad request
            return badRequest(addProduct.render(newProductForm));
        } else {
            // No errors found - extract the product detail from the form
            Product newProduct = newProductForm.get();

            // Save the object to the Products table in the database
            newProduct.save();

            // Set a success message to flash (for display in return view)
            flash("success", "Product " + newProduct.getName() + " was added");

            // Redirect to the index page
            return redirect(controllers.routes.HomeController.index());
        }

        




    }

}
